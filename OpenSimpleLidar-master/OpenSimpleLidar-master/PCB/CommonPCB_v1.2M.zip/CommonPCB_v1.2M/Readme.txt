Project files - PCB and schematic.  
Note that I don't test them.
V1.2M - version for M12 lens holder with 20mm hole distance.
There are no changes in schematic against "v1.2" PCB.
See assembling pictures in "CommonPCB_v1.2" folder.